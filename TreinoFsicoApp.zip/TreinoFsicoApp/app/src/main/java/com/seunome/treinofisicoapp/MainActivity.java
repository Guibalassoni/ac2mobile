package com.seunome.treinofisicoapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ArrayList<Exercise> exercises = new ArrayList<>();
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView listView = findViewById(R.id.exerciseListView);
        Button addExerciseButton = findViewById(R.id.addExerciseButton);
        Button startWorkoutButton = findViewById(R.id.startWorkoutButton);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<>());
        listView.setAdapter(adapter);

        addExerciseButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddExerciseActivity.class);
            startActivityForResult(intent, 1);
        });

        startWorkoutButton.setOnClickListener(v -> {
            Intent serviceIntent = new Intent(MainActivity.this, WorkoutService.class);
            serviceIntent.putParcelableArrayListExtra("exercises", exercises);
            startService(serviceIntent);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK) {
            Exercise exercise = data.getParcelableExtra("exercise");
            exercises.add(exercise);
            adapter.add(exercise.getName());
        }
    }
}
