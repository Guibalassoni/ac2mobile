package com.seunome.treinofisicoapp;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

import java.util.ArrayList;

public class WorkoutService extends Service {
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        ArrayList<Exercise> exercises = intent.getParcelableArrayListExtra("exercises");
        if (exercises != null) {
            for (Exercise exercise : exercises) {
                // Simula a execução de cada exercício (apenas para demonstração)
                try {
                    Thread.sleep(exercise.getDuration() * 1000L);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
