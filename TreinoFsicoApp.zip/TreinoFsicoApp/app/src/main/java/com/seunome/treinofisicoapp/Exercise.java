package com.seunome.treinofisicoapp;

import android.os.Parcel;
import android.os.Parcelable;

public class Exercise implements Parcelable {
    private String name;
    private int duration;

    public Exercise(String name, int duration) {
        this.name = name;
        this.duration = duration;
    }

    protected Exercise(Parcel in) {
        name = in.readString();
        duration = in.readInt();
    }

    public static final Creator<Exercise> CREATOR = new Creator<Exercise>() {
        @Override
        public Exercise createFromParcel(Parcel in) {
            return new Exercise(in);
        }

        @Override
        public Exercise[] newArray(int size) {
            return new Exercise[size];
        }
    };

    public String getName() {
        return name;
    }

    public int getDuration() {
        return duration;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeInt(duration);
    }

    @Override
    public int describeContents() {
        return 0;
    }
}
