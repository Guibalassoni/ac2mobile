package com.example.circuitodetreino;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface ExercicioDao {
    @Insert
    void insert(Exercicio exercicio);

    @Query("SELECT * FROM Exercicio")
    List<Exercicio> getAll();

    @Query("DELETE FROM Exercicio")
    void deleteAll();
}
