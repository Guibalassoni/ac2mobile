package com.example.circuitodetreino;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class CadastroActivity extends AppCompatActivity {
    private EditText nomeExercicio;
    private EditText duracaoExercicio;
    private Button btnSalvar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        nomeExercicio = findViewById(R.id.nomeExercicio);
        duracaoExercicio = findViewById(R.id.duracao);
        btnSalvar = findViewById(R.id.btnSalvar);

        btnSalvar.setOnClickListener(v -> salvarExercicio());
    }

    private void salvarExercicio() {

        String nome = nomeExercicio.getText().toString();
        String duracaoStr = duracaoExercicio.getText().toString();

        if (TextUtils.isEmpty(nome) || TextUtils.isEmpty(duracaoStr)) {
            Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
            return;
        }

        int duracao;
        try {
            duracao = Integer.parseInt(duracaoStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "A duração deve ser um número!", Toast.LENGTH_SHORT).show();
            return;
        }

        if (duracao <= 0) {
            Toast.makeText(this, "A duração deve ser maior que zero!", Toast.LENGTH_SHORT).show();
            return;
        }

        Exercicio novoExercicio = new Exercicio(nome, duracao);

        // Mover a operação de banco para uma thread separada
        Executor executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            AppDatabase db = AppDatabase.getInstance(getApplicationContext());
            db.exercicioDao().insert(novoExercicio);

            // Atualizar a UI na thread principal após salvar
            runOnUiThread(() -> {
                Toast.makeText(CadastroActivity.this, "Exercício cadastrado com sucesso!", Toast.LENGTH_SHORT).show();

                // Voltar para a MainActivity
                Intent intent = new Intent(CadastroActivity.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            });
        });
    }
}
