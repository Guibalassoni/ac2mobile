package com.example.circuitodetreino;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.Handler;
import android.util.Log;

import java.io.Serializable;
import java.util.List;

public class TreinoService extends Service {

    private Handler handler = new Handler();
    private List<Exercicio> listaExercicios;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            listaExercicios = (List<Exercicio>) intent.getSerializableExtra("listaExercicios");
            if (listaExercicios != null) {
                iniciarTreino();
            }
        }
        return START_STICKY;
    }

    private void iniciarTreino() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                for (Exercicio exercicio : listaExercicios) {
                    for (int i = exercicio.duracao; i >= 0; i--) {
                        final int tempoRestante = i;
                        final String nomeExercicio = exercicio.nome;

                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                Intent intent = new Intent("TIMER_UPDATE");
                                intent.putExtra("tempoRestante", tempoRestante);
                                intent.putExtra("exercicioAtual", nomeExercicio);
                                sendBroadcast(intent);
                            }
                        });

                        try {
                            Thread.sleep(1000); // Espera 1 segundo
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }).start();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
