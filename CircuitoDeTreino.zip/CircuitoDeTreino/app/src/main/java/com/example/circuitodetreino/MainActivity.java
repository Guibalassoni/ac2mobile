package com.example.circuitodetreino;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.room.Room;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;

import java.io.Serializable;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Obter os exercícios (substituir por banco ou lista fixa para teste)
        List<Exercicio> listaExercicios = obterListaExercicios();

        findViewById(R.id.btnIniciar).setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, TreinoService.class);
            intent.putExtra("listaExercicios", (Serializable) listaExercicios);
            startService(intent);
        });

        findViewById(R.id.btnCadastrar).setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, CadastroActivity.class);
            startActivity(intent);
        });
    }

    @SuppressLint("UnspecifiedRegisterReceiverFlag")
    @Override
    protected void onResume() {
        super.onResume();
        IntentFilter intentFilter = new IntentFilter("TIMER_UPDATE");
        registerReceiver(timerReceiver, intentFilter, Context.RECEIVER_NOT_EXPORTED);
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(timerReceiver);
    }

    private final BroadcastReceiver timerReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            long tempoRestante = intent.getLongExtra("tempoRestante", 0);
            String exercicioAtual = intent.getStringExtra("exercicioAtual");

            // Atualizar a UI
            Log.d("TIMER", "Tempo restante: " + tempoRestante);
        }
    };

    private List<Exercicio> obterListaExercicios() {
        // Adicionar lógica para obter exercícios do banco ou criar uma lista para teste
        return List.of(
                new Exercicio("Agachamento", 30),
                new Exercicio("Flexão", 20),
                new Exercicio("Descanso", 10)
        );
    }
}