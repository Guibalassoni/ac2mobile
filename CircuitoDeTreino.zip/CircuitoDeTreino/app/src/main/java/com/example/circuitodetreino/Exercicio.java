package com.example.circuitodetreino;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;

@Entity
public class Exercicio implements Serializable { // Implementação de Serializable
    @PrimaryKey(autoGenerate = true)
    public int id;

    public String nome;
    public int duracao;

    // Construtor padrão exigido pelo Room
    public Exercicio() {
    }

    public Exercicio(String nome, int duracao) {
        this.nome = nome;
        this.duracao = duracao;
    }

    // Getters e Setters opcionais para acessar os campos
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getDuracao() {
        return duracao;
    }

    public void setDuracao(int duracao) {
        this.duracao = duracao;
    }
}
