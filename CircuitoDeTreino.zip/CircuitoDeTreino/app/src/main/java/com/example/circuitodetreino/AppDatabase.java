package com.example.circuitodetreino;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {Exercicio.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {
    private static AppDatabase INSTANCE;

    public abstract ExercicioDao exercicioDao();

    public static synchronized AppDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                            AppDatabase.class, "circuito_de_treino_db")
                    .fallbackToDestructiveMigration() // Gerenciar alterações de schema
                    .build();
        }
        return INSTANCE;
    }
}
